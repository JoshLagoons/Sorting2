﻿using System;
using static System.Console;
using System.Collections;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Numerics;
using System.Collections.Generic;
using System.Linq;
using System.Text.Encodings;

namespace Sorting
{
    class Program
    {
        private static IEnumerable<string> myArray;

        static void Main(string[] args)
        {
            WriteLine("Linear search");
            //Best case
            Linear_searchB();
            //worst case
            Linear_searchW();
            //pseudocode
            //Begin
            //1) Set i = 0
            //2) If Li = T, go to line 4
            //3) Increase i by 1 and go to line 2
            //4) If i<n then return i
            //End

            Clear();
            WriteLine("Binary search");
            //Best case 
            Binary_searchB();
            //worst case
            Binary_searchW();
            Clear();
            //pseudocode
            //function binary_search(A, n, T) is
            //L := 0
            //R:= n − 1
            //while L ≤ R do
            //m:= floor((L + R) / 2)
            //if A[m] < T then
            //L := m + 1
            //else if A[m] > T then
            //R := m − 1
            //else:
            //return m
            //return unsuccessful
            Clear();
            WriteLine("Interpolation search");
            //Best case
            Inter_searchB();
            //Worst case
            Inter_searchW();
            //pseudocode 
            //start =0
            //end = len(arr) -1
            //found = false
            //while found == false and start <=end
            //{            
            //  pos = start + (((end-start)/(arr[end]-arr[start])) * (target-arr[start]))       
            //  if arr[pos]==target
            //     {
            //        return pos
            //     }
            //  if target > arr[pos]
            //     {
            //         start = pos+1
            //     }
            //  else
            //     {
            //      end = pos-1
            //     }
            //}
        }
        public static void Linear_searchB()   // Search for values
        {
            WriteLine("This is the best case\n");
            WriteLine("1 = Number");
            int operation = Convert.ToInt32(ReadLine());
            if (operation == 1)
            {
                String[] myArray = File.ReadAllLines("scores.txt");
            }

            WriteLine("Enter number to search");
            String myString = ReadLine();
            int search = 0;
            int nosearch = 0;
            var regex = new Regex(myString);
            foreach (string array in myArray)
            {
                if (regex.IsMatch(array))
                {
                    search++;
                }

                else if (regex.IsMatch(array))
                {
                    nosearch++;
                }
            }

            if (search > 0)
            {
               WriteLine("Found match! - {1} Appeared {0} time(s)", search, myString);
            }

            else if (nosearch == 0)
            {
                WriteLine("No Match for {0} in Data", myString);
            }

            ReadLine();
        }
        public static void Linear_searchW()   // Search for values
        {
            WriteLine("This is the worse case \n");
            WriteLine("1 = Number");
            int operation = Convert.ToInt32(ReadLine());
            if (operation == 1)
            {
                String[] myArray = File.ReadAllLines("scores.txt");
            }

            WriteLine("Enter number to search");
            String myString = ReadLine();
            int search = 0;
            int nosearch = 100;
            var regex = new Regex(myString);
            foreach (string array in myArray)
            {
                if (regex.IsMatch(array))
                {
                    search++;
                }

                else if (regex.IsMatch(array))
                {
                    nosearch++;
                }
            }

            if (search > 0)
            {
                WriteLine("Found match! - {1} Appeared {0} time(s)", search, myString);
            }

            else if (nosearch == 100)
            {
                WriteLine("No Match for {0} in Data", myString);
            }

            ReadLine();
        }
        public static int Binary_searchB()
        {

            WriteLine("This is the best case\n");
            int operation2 = Convert.ToInt32(ReadLine());
            int[] arr = new int[] { Convert.ToInt32(ReadLine()) };
            if (operation2 == 1)
            {
                String[] myArray = File.ReadAllLines("scores.txt");

            }
            int minNum = 0;
            int maxNum = arr.Length - 1;

                while (minNum <= maxNum)
                {
                    int middlepoint = (minNum + maxNum) / 2;
                    if (operation2 == arr[middlepoint])
                    {
                        return ++middlepoint;
                    }
                    else if (operation2 < arr[middlepoint])
                    {
                        maxNum = middlepoint - 1;
                    }
                    else
                    {
                        minNum = middlepoint + 1;
                    }
                }
                return 0;
            
        }
        public static int Binary_searchW()
        {
            WriteLine("This is the worst case\n");
            int operation2 = Convert.ToInt32(ReadLine());
            int[] arr = new int[] { Convert.ToInt32(ReadLine()) };
            if (operation2 == 1)
            {
                String[] myArray = File.ReadAllLines("scores.txt");

            }
            int minNum = 0;
            int maxNum = arr.Length - 1;

            while (minNum <= maxNum)
            {
                int middlepoint = (minNum + maxNum) / 8;
                if (operation2 == arr[middlepoint])
                {
                    return ++middlepoint;
                }
                else if (operation2 < arr[middlepoint])
                {
                    maxNum = middlepoint - 10;
                }
                else
                {
                    minNum = middlepoint + 100;
                }
            }
            return 0;
        }
        public static void Inter_searchB()
        {
            WriteLine("This is the best case\n");
            // the file will be search and starts after seeing the text
            int operation1 = Convert.ToInt32(ReadLine());
            int[] arr = new int[]{ Convert.ToInt32(ReadLine())}; 
            WriteLine("1 = Number");
            if (operation1==1)
            {
                String[] myArray = File.ReadAllLines("scores.txt");

            }
            // The file is getting searched                 
            int x = 100;
            int nom = arr.Length;
            int index = interSearch(arr, 0, nom - 1, x);

            // If the input was found
            if (index != -1)
                WriteLine("The score is found at " +
                                   index);
            else
                WriteLine("Score isn't found.");

        }
        public static void Inter_searchW()
        {
            WriteLine("This is the worst case\n");
            int operation1 = Convert.ToInt32(ReadLine());
            int[] inter= new int[] { Convert.ToInt32(ReadLine()) };
        
            WriteLine($"Finding the numbers of {{{string.Join(" ", inter)}}}.");
            if (operation1 == 1)
            {
                String[] myArray = File.ReadAllLines("scores.txt");

            }

            int x = 10;
            int nok = inter.Length;
            int index = interSearch(inter, 0, nok - 1, x);

            // If the input was found
            if (index != -1)
                WriteLine("The score is found at " +
                                   index);
            else
                WriteLine("Score isn't found.");

        }
        static int interSearch(int[] arr, int lower,
                               int higher, int x)
        {
            int note;

            // Since the number is sorted, the output present within the range
            if (lower <= higher && x >= arr[lower] &&
                            x <= arr[higher])
            {

                // Finding the position
                note = lower + (((higher - lower) /
                        (arr[higher] - arr[lower])) *
                              (x - arr[lower]));

                //if it find the number
                if (arr[note] == x)
                    return note;

                // If x is larger, x is in right sub array 
                if (arr[note] < x)
                    return interSearch(arr, note + 1,
                                               higher, x);

                // If x is smaller, x is in left sub array 
                if (arr[note] > x)
                    return interSearch(arr, lower,
                                               note - 1, x);
            }
            return -1;
        }
    }
}
